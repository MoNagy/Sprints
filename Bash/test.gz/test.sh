#!/bin/bash
echo "give me your name"
read name

echo "your name is $name,$1"